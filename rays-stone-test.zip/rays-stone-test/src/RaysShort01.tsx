import {AbsoluteFill, Sequence} from 'remotion';
import {Hook} from './scenes/Hook';
import {Reveal} from './scenes/Reveal';
import {Climax} from './scenes/Climax';
import {EndCard} from './scenes/EndCard';
import {FontReady} from './components/Design';

export const RaysShort01 = () => (
  <FontReady>
    <AbsoluteFill style={{backgroundColor: '#07121f'}}>
      <Sequence from={0} durationInFrames={90}><Hook /></Sequence>
      <Sequence from={90} durationInFrames={150}><Reveal /></Sequence>
      <Sequence from={240} durationInFrames={150}><Climax /></Sequence>
      <Sequence from={390} durationInFrames={60}><EndCard /></Sequence>
    </AbsoluteFill>
  </FontReady>
);
