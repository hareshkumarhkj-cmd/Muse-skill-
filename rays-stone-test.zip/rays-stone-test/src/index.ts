import {createElement} from 'react';
import {Composition, registerRoot} from 'remotion';
import {RaysShort01} from './RaysShort01';

export const RemotionRoot = () => createElement(Composition, {
  id: 'RaysShort01',
  component: RaysShort01,
  durationInFrames: 450,
  fps: 30,
  width: 1080,
  height: 1920,
});

registerRoot(RemotionRoot);
